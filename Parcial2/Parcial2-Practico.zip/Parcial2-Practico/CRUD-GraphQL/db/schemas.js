const { gql } = require('apollo-server');

//GraphQL
const typeDefs = gql `
    #Modelos
    type Usuario {
        id: ID
        nombre: String
        apellido: String
        email: String
        creado: String
    }
    
    type Producto {
        id: ID
        nombre: String
        existencia: Int
        precio: Float
        creado: String
    }
    
    type Categoria {
        id: ID
        sigla: String
        codigo: String
        codigoSubCategoria: String
        nombre: String
        creado: String
    }

    #Inputs
    input inputCategoria {
        sigla: String
        codigo: String
        nombre: String
        creado: String
    }
    
    input inputActualizarCategoria {
        id: ID!
        sigla: String
        codigo: String
        nombre: String
        creado: String

    }
    
    input inputUsuario {
        nombre: String
        apellido: String
        email: String
        password: String
    }  
    
    input inputProducto {
        nombre: String!
        existencia: Int!
        precio: Float!
    }
    
    input inputActualizarProducto {
    id: ID!
    nombre: String
    existencia: Int
    precio: Float
}

    
    
    type Token {
        token: String  
    }
    
    type Query {
        obtenerUsuario(token: String): Usuario
        obtenerProductos: [Producto]
        obtenerProducto(id: ID!): Producto
        obtenerCategoria(id: ID!): Categoria
        obtenerCategorias: [Categoria]
        
    } 
    input autenticarInput {
        email: String
        password: String
    }   
    
    type Mutation {
        #Usuarios
        nuevoUsuario(input: inputUsuario): Usuario
        autenticarUsuario(token: autenticarInput): Token
        
        #Productos 
        nuevoProducto(input: inputProducto): Producto
        actualizarProducto(id: ID!, input: inputActualizarProducto): Producto
        eliminarProducto(id: ID!): String
        
        #Categorias 
        nuevaCategoria(input: inputCategoria): Categoria
        actualizarCategoria(id: ID!, input: inputActualizarCategoria): Categoria
        eliminarCategoria(id: ID!): String

        
        
    }
   
     
    
    
`;

module.exports = typeDefs;