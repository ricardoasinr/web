const mongoose = require('mongoose');

const CategoriaSchema = mongoose.Schema({
    sigla: {
        unique: true,
        type: String,
        required: true,
        trim: true
    },
    codigo: {
        unique: true,
        type: String,
        required: true,
        trim: true
    },
    codigoSubCategoria: {
        type: String,
        required: true,
        trim: true,


    },
    nombre: {
        type: String,
        required: true,
        trim: true,
    },
    creado: {
        type: Date,
        required: true
    }
});

module.exports = mongoose.model('Categoria', CategoriaSchema);