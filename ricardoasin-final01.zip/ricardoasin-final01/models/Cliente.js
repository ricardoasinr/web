const mongoose = require('mongoose');
const ClienteSchema = mongoose.Schema({
    nombre: {
        type: String,
        required: true,
        trim: true
    },
    apellido: {
        type: String,
        required: true,
        trim: true
    },

    email: {
        type: String,
        required: true,
        trim: true,
        unique: true
    },
    tipoCliente: {
        type: String,
        default: 'Regular'
    },
    oficialDeCredito: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'OficialDeCredito'
    },



    creado: {
        type: Date,
        default: Date.now()
    },


})

module.exports = mongoose.model('Cliente', ClienteSchema);