const {ApolloServer} = require('apollo-server');

const conectarDB = require('./config/db');
const typeDefs = require('./db/schemas');
const resolvers = require('./db/resolvers');


//Temporal
const jwt = require('jsonwebtoken');
//Aquí se importan las variables
require('dotenv').config({path:'variables.env'});

//Levantar la Base de Datos
conectarDB();

//Servidor
const servidor = new ApolloServer({
    typeDefs,
    resolvers,
    context: ({req} ) =>{
        //El token retornara verdadero o falso
        const token = req.headers['authorization'] || '';
        //Verificar si este token es correcto
        if(token){
            try {
                const OFICIAL =jwt.verify(token, process.env.FIRMA)
                console.log(OFICIAL)
                return {
                    OFICIAL
                }
            }catch(error){
                console.log('Hubo un error!')
                console.log(error)
            }
        }

    }
});

//Levantar el servidor
servidor.listen().then(({url}) =>{
    console.log(`Servidor listo en la URL: ${url}`)
})