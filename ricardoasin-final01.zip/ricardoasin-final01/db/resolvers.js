const OficialDeCredito = require('../models/OficialDeCredito')
const Cliente = require('../models/Cliente')

const bcryptjs = require('bcryptjs');


const jwt = require('jsonwebtoken');
//Aquí se importan las variables
require('dotenv').config({path:'variables.env'});

//Aquí se crea la función que nos permite crear el token
const crearToken = (oficialDeCredito, firma, expiresIn) => {
    const {id, email, nombre, apellido, banco} = oficialDeCredito;
    return jwt.sign({id, email, nombre, apellido, banco}, firma, {expiresIn})
}


const resolvers = {
    Query: {
        obtenerOficialDeCredito: async (_, {token}) => {
            console.log("Obteniendo oficial de credito")
            const oficialDeCreditoID = await jwt.verify(token, process.env.FIRMA)
            console.log(oficialDeCreditoID)

            return oficialDeCreditoID
        },
        obtenerOficialesDeCredito: async () => {
            try {
                const oficiales = await OficialDeCredito.find({});
                return oficiales;
            } catch (error) {
                console.log(error);
            }
        },



        obtenerClientes: async () => {
            try {
                const clientes = await Cliente.find({});
                return clientes;
            } catch (error) {
                console.log(error);
            }
        },

        obtenerCliente: async (_, { id }) => {
            // Revisar si el cliente existe
            const cliente = await Cliente.findById(id);

            if (!cliente) {
                throw new Error('Cliente no encontrado');
            }

            return cliente;
        },
        obtenerClientesAsignadosAOficialDeCredito: async (_, {}, context) => {
            try {
                return await Cliente.find({oficialDeCredito: context.OFICIAL.id})
            } catch (error) {
                console.log("Error al obtener los clientes asignados a un oficial de credito");
                console.log(error);
            }
        },






    },
    Mutation: {

        //CRUD OFICIAL DE CREDITO
        nuevoOficialDeCredito: async (_,{ input } ) => {
            console.log(input);
            const { email, password } = input;
            //Revisar si el oficial está registrado
            const existeOficial = await  OficialDeCredito.findOne({email});
            if(existeOficial){
                throw new Error(`El oficial de credito con ese mail ${email} ya fue registrado`)
            }
            //Hash-ear el password
            const salt = await bcryptjs.genSaltSync(10);
            input.password = await bcryptjs.hash(password, salt);

            //Guardarlo en la Base de Datos
            try {
                const oficialDeCredito = new OficialDeCredito(input);
                console.log(oficialDeCredito);
                await oficialDeCredito.save();
                return oficialDeCredito;
            } catch (error){
                console.log(error);
            }
            return "Creando oficial de credito....";
        },

        autenticarOficialDeCredito: async (_,{ token }) => {
            console.log(token);
            const {email, password} = token;
            //Verificar si el Usuario existe
            //Revisar si el Usuario está registrado

            const existeUsuario = await  OficialDeCredito.findOne({email});
            //console.log(`existeUsuario: ${existeUsuario}`);
            if(!existeUsuario){
                throw new Error(`El usuario con ese mail ${email} no existe`)
            }
            //Revisar si el password es correcto

            const passwordCorrecto = await bcryptjs.compare(password, existeUsuario.password);
            if(!passwordCorrecto){
                throw new Error(`El password es incorrecto ${password}`)
            }

            //Crear token


            return  {
                token: crearToken(existeUsuario, process.env.FIRMA, "24000000000")
            }

        },
        actualizarOficialDeCredito: async (_, { id, input }) => {
            let oficial = await OficialDeCredito.findById(id);

            if (!oficial) {
                throw new Error('Oficial de credito no encontrado');
            }
            const { email, password } = input;
            //Revisar si el email del oficial está registrado
            const existeOficial = await  OficialDeCredito.findOne({email});
            if(existeOficial){
                throw new Error(`El oficial de credito con ese mail ${email} ya fue registrado`)
            }

            oficial = await OficialDeCredito.findOneAndUpdate({ _id: id }, input, { new: true });

            return oficial;
        },

        eliminarOficialDeCredito: async (_, { id }) => {
            // Revisar si el cliente existe
            let oficial = await OficialDeCredito.findById(id);

            if (!oficial) {
                throw new Error('Oficial de credito no encontrado');
            }

            // Eliminar el cliente de la Base de Datos
            await OficialDeCredito.findOneAndDelete({ _id: id });

            return 'Oficial de crédito eliminado correctamente';
        },







        //CRUD Cliente
        nuevoCliente: async (_, { input }, context) => {

            const {nombre, apellido, email} = input;
            //Verificar si el client existe
            const clienteExiste = await Cliente.findOne({email})
            if(clienteExiste){
               throw new Error('El cliente ya existe');
            }
            //Asignar el vendedor al cliente
            const nuevoCliente = new Cliente(input)
            nuevoCliente.oficialDeCredito = context.OFICIAL.id
            try {
                console.log(nuevoCliente);
                await nuevoCliente.save();
                return nuevoCliente;
                
            }catch (error){
                console.log(error);
            }

        },

        actualizarCliente: async (_, { id, input }) => {
            // Revisar si el cliente existe
            let cliente = await Cliente.findById(id);

            if (!cliente) {
                throw new Error('Cliente no encontrado');
            }

            // Guardar el cliente en la Base de Datos
            cliente = await Cliente.findOneAndUpdate({ _id: id }, input, { new: true });

            return cliente;
        },

        eliminarCliente: async (_, { id }) => {
            // Revisar si el cliente existe
            let cliente = await Cliente.findById(id);

            if (!cliente) {
                throw new Error('Cliente no encontrado');
            }

            // Eliminar el cliente de la Base de Datos
            await Cliente.findOneAndDelete({ _id: id });

            return 'Cliente eliminado correctamente';
        },











}



}

module.exports = resolvers;