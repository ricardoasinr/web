const { gql } = require('apollo-server');

//GraphQL
const typeDefs = gql `
    #Modelos
    type OficialDeCredito {
        id: ID
        nombre: String
        apellido: String
        email: String
        banco: String
        creado: String
    }
    
    type Cliente {
        id: ID
        nombre: String
        apellido: String
        email: String
        oficialDeCredito: ID
    }

   

    #Inputs
    input inputOficialDeCredito {
        nombre: String
        apellido: String
        email: String
        banco: String
        password: String
    } 
    input inputActualizarOficialDeCredito {
        id: ID!
        nombre: String
        apellido: String
        email: String
        banco: String
        password: String
    }  
    
    input inputCliente {
        nombre: String
        apellido: String
        email: String
        tipoCliente: TipoCliente
        
    }
   
    input inputActualizarCliente {
        id: ID!
        nombre: String
        apellido: String
        email: String
        tipoCliente: TipoCliente
       
         
    }
    
       input autenticarInput {
        email: String
        password: String
    }   
    
    
    type Token {
        token: String  
    }
 
    
    enum TipoCliente{
        Excelente
        Bueno
        Regular
    }

    
    
    type Query {
        obtenerOficialDeCredito(token: String): OficialDeCredito
        obtenerOficialesDeCredito: [OficialDeCredito]
   
        
        obtenerClientes: [Cliente]
        obtenerCliente(id: ID!): Cliente
        obtenerClientesAsignadosAOficialDeCredito: [Cliente]
        
    } 
 
    
    type Mutation {
        #Usuarios
        nuevoOficialDeCredito(input: inputOficialDeCredito): OficialDeCredito
        autenticarOficialDeCredito(token: autenticarInput): Token
        actualizarOficialDeCredito(id: ID!,input: inputActualizarOficialDeCredito): OficialDeCredito
        eliminarOficialDeCredito(id: ID!): String
        
       
        #Cliente
        nuevoCliente(input: inputCliente): Cliente
        actualizarCliente(id: ID!, input: inputActualizarCliente): Cliente
        eliminarCliente(id: ID!): String
        
       



        
        
    }
   
     
    
    
`;

module.exports = typeDefs;